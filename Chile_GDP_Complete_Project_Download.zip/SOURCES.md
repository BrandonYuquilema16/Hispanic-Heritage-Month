# Source Documentation — Chile GDP Explorer (1976–2026)

## Primary historical-data source

**World Bank. (2026). _World Development Indicators: GDP (current US$), Chile (NY.GDP.MKTP.CD)._** World Bank. Accessed October 29, 2026.

Official indicator page: https://data.worldbank.org/indicator/NY.GDP.MKTP.CD?locations=CL

Official source/API for Chile (CHL): https://api.worldbank.org/v2/country/CHL/indicator/NY.GDP.MKTP.CD?format=json

World Bank indicator metadata and definition: https://databank.worldbank.org/metadataglossary/world-development-indicators/series/NY.GDP.MKTP.CD

World Bank API documentation: https://datahelpdesk.worldbank.org/knowledgebase/articles/898599-indicator-api-queries

Data are supplied by the World Bank's **World Development Indicators (WDI)**, using national accounts data from official statistics and international statistical sources. The World Bank indicator page lists the license as **Creative Commons Attribution 4.0 (CC BY 4.0)**: https://creativecommons.org/licenses/by/4.0/

## What exactly is being measured?

- **Country:** Chile (CHL / CL)
- **Indicator:** NY.GDP.MKTP.CD
- **Indicator name:** GDP (current US$)
- **Output variable (y):** Gross domestic product in **billions of current U.S. dollars**
- **Input variable:** Year, from 1976 through 2025 for the observed data
- **Regression input (x):** Year − 1976, so x = 0 in 1976
- **Conversion:** GDP in billions of USD = GDP (current US$) / 1,000,000,000

GDP measures production in an economy over a year. **It is not the country's net worth** (assets minus liabilities). Because this series is in *current* USD, it is not adjusted for inflation and is affected by currency exchange rates.

## Observations versus predictions

The attached `chile_gdp_source_data.csv` contains **50 observed annual records**, 1976–2025, transcribed from the World Bank Indicators API response as published when accessed on October 29, 2026. **There is no observed 2026 GDP row in this source file.** The app produces a **2026 model estimate** by extrapolating a polynomial trained only on available historical observations. Such extrapolation is uncertain and is not an official World Bank forecast.

The app also fetches live GDP values when it runs; therefore World Bank revisions may make the latest live data differ slightly from this static source CSV.

## Mathematical method

The app fits a degree-3 or higher least-squares polynomial, for example:

    GDP(x) = a*x^3 + b*x^2 + c*x + d
    x = Year - 1976
    GDP'(x) = 3*a*x^2 + 2*b*x + c
    GDP''(x) = 6*a*x + 2*b

Coefficients are **calculated from data** and are not fixed in this source document. `GDP'(x)` approximates the modeled annual GDP change in billions USD/year; `GDP''(x)` approximates the change in that rate. Fitted R-squared and RMSE measure fit against the used history; they do not prove forecasting accuracy.

## How this project addresses the assignment

The 1976 start was chosen for the assignment's study period; it is **not the start of Chile's economic history or the first year in World Bank's series** (which begins in 1960). The source CSV preserves the raw observations, and the app lets students inspect and optionally edit a **separate working copy**. Any edited values are no longer untouched World Bank observations.

## Attribution text to use in your report

> Source: World Bank, World Development Indicators, “GDP (current US$) — Chile,” indicator NY.GDP.MKTP.CD, accessed October 29, 2026, https://data.worldbank.org/indicator/NY.GDP.MKTP.CD?locations=CL. Licensed CC BY 4.0. Data converted from U.S. dollars to billions of U.S. dollars for display. 2026 is a polynomial model estimate, not an observed historical value.
