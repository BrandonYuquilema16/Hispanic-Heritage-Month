# Chile GDP Explorer 🇨🇱

An interactive Hispanic Heritage Month Streamlit app using **verified World Bank GDP (current US$) data for Chile, beginning in 1976**, with a clearly marked **2026 polynomial estimate**.

## GitHub + Streamlit Community Cloud

1. Create or open your public GitHub repository.
2. Put **`app.py`** and **`requirements.txt`** in the **same folder**, ideally at the top level. Do not upload the ZIP as your app entrypoint.
3. If the repository contains an older `app (11).py`, configure Streamlit to run the new `app.py` (or remove the old one).
4. Deploy the repository from <https://share.streamlit.io/>, choosing `app.py` as the entrypoint.
5. Commit changes and reboot the app if the Cloud environment is using outdated dependencies.

Your repository should look like:

```
hispanic-app/
├── app.py
├── requirements.txt
└── README.md        (optional)
```

## Run locally

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## What the app does

- Downloads real Chile GDP values from World Bank WDI code `NY.GDP.MKTP.CD` (current USD) for 1976 through the latest year **before 2026**.
- Displays untouched source data and a separate editable scenario table; original World Bank values are never overwritten.
- Fits degree 3–6 polynomials and shows the equation, first derivative and second derivative.
- Calculates R², RMSE, MAE, and model residuals.
- Plots actual points, fitted curve, and a clearly separated 2026 prediction.
- Offers a year slider that moves the highlighted model point and its tangent (slope) line; optional additional slope lines.
- Predicts selected years, including multiple years entered at once.
- Downloads CSVs, standalone interactive Plotly HTML, and a PDF report containing a graph and the full raw dataset.
- Provides cultural/economic context and a Chile fun-fact section.

## Source and important caveats

World Bank: <https://data.worldbank.org/indicator/NY.GDP.MKTP.CD?locations=CL>.

GDP measures annual production, not national net worth. Data are **nominal GDP in current US dollars**, not inflation adjusted. The historical window starts in 1976 by assignment choice, not Chile's founding. All 2026 values are **mathematical estimates**, not official observations. Live access to the World Bank API is required: if unavailable, the app shows a helpful error rather than fabricating data.


## Data sources for your teacher

- `SOURCES.md` describes the World Bank indicator and citations.
- `chile_gdp_source_data.csv` is a dated historical-data snapshot (1976–2025); the app fetches up-to-date values directly from World Bank when launched.
